﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikesFactory
{
    public enum EnumBikes
    {
        Road,
        Mountain,
        unkonw
    }
}