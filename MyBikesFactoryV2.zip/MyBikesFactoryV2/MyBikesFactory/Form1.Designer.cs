﻿namespace MyBikesFactory
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lstViewMountain = new System.Windows.Forms.ListView();
            this.columnHeaderSerial = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderModel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderColor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMonth = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeadertype = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderWheel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSpeeds = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSuspension = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderGroundH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.txtSerial = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cboColor = new System.Windows.Forms.ComboBox();
            this.txtDay = new System.Windows.Forms.TextBox();
            this.txtMonth = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtWheel = new System.Windows.Forms.TextBox();
            this.txtSpeeds = new System.Windows.Forms.TextBox();
            this.txtSeatH = new System.Windows.Forms.TextBox();
            this.txtGroundH = new System.Windows.Forms.TextBox();
            this.cboSuspension = new System.Windows.Forms.ComboBox();
            this.cboPedal = new System.Windows.Forms.ComboBox();
            this.btnDisplayAll = new System.Windows.Forms.Button();
            this.btnDisplayMountain = new System.Windows.Forms.Button();
            this.btnDisplayRoad = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.cboBikeType = new System.Windows.Forms.ComboBox();
            this.lstViewRoad = new System.Windows.Forms.ListView();
            this.columnHeaderRSerial = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRModel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRColor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRDay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRMoth = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRtype = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRWheel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRSpeeds = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSeatH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPedal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(41, 54);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(39, 94);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search by Serial";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(163, 97);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(121, 20);
            this.txtSearch.TabIndex = 2;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(129, 54);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(219, 54);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 4;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(41, 25);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(108, 23);
            this.btnRead.TabIndex = 5;
            this.btnRead.Text = "Read From File";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(163, 25);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(108, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "SaveTo File ";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lstViewMountain
            // 
            this.lstViewMountain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderSerial,
            this.columnHeaderModel,
            this.columnHeaderColor,
            this.columnHeaderDay,
            this.columnHeaderMonth,
            this.columnHeaderYear,
            this.columnHeadertype,
            this.columnHeaderWheel,
            this.columnHeaderSpeeds,
            this.columnHeaderSuspension,
            this.columnHeaderGroundH,
            this.columnHeaderSize});
            this.lstViewMountain.Location = new System.Drawing.Point(334, 94);
            this.lstViewMountain.Name = "lstViewMountain";
            this.lstViewMountain.Size = new System.Drawing.Size(419, 97);
            this.lstViewMountain.TabIndex = 8;
            this.lstViewMountain.UseCompatibleStateImageBehavior = false;
            this.lstViewMountain.View = System.Windows.Forms.View.Details;
            this.lstViewMountain.SelectedIndexChanged += new System.EventHandler(this.lstViewMountain_SelectedIndexChanged);
            // 
            // columnHeaderSerial
            // 
            this.columnHeaderSerial.Text = "Serial";
            // 
            // columnHeaderModel
            // 
            this.columnHeaderModel.Text = "Model";
            // 
            // columnHeaderColor
            // 
            this.columnHeaderColor.Text = "Color";
            // 
            // columnHeaderDay
            // 
            this.columnHeaderDay.Text = "M-Day";
            // 
            // columnHeaderMonth
            // 
            this.columnHeaderMonth.Text = "M-Month";
            // 
            // columnHeaderYear
            // 
            this.columnHeaderYear.Text = "M-Year";
            // 
            // columnHeadertype
            // 
            this.columnHeadertype.DisplayIndex = 11;
            this.columnHeadertype.Text = "type";
            // 
            // columnHeaderWheel
            // 
            this.columnHeaderWheel.DisplayIndex = 6;
            this.columnHeaderWheel.Text = "Wheel Size";
            // 
            // columnHeaderSpeeds
            // 
            this.columnHeaderSpeeds.DisplayIndex = 7;
            this.columnHeaderSpeeds.Text = "Speeds";
            // 
            // columnHeaderSuspension
            // 
            this.columnHeaderSuspension.DisplayIndex = 8;
            this.columnHeaderSuspension.Text = "Suspension";
            // 
            // columnHeaderGroundH
            // 
            this.columnHeaderGroundH.DisplayIndex = 9;
            this.columnHeaderGroundH.Text = "Ground Heigth";
            // 
            // columnHeaderSize
            // 
            this.columnHeaderSize.DisplayIndex = 10;
            this.columnHeaderSize.Text = "Size";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "SerialNumber";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtSerial
            // 
            this.txtSerial.Location = new System.Drawing.Point(161, 166);
            this.txtSerial.Name = "txtSerial";
            this.txtSerial.Size = new System.Drawing.Size(121, 20);
            this.txtSerial.TabIndex = 10;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(161, 198);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(121, 20);
            this.txtModel.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Color";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Made Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Wheel Size";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 329);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Speeds";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "SeatHeigth";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 393);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Pedal Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 425);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Supension";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 457);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Ground Heigth";
            // 
            // cboColor
            // 
            this.cboColor.FormattingEnabled = true;
            this.cboColor.Location = new System.Drawing.Point(161, 230);
            this.cboColor.Name = "cboColor";
            this.cboColor.Size = new System.Drawing.Size(121, 21);
            this.cboColor.TabIndex = 21;
            // 
            // txtDay
            // 
            this.txtDay.Location = new System.Drawing.Point(161, 262);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(27, 20);
            this.txtDay.TabIndex = 22;
            // 
            // txtMonth
            // 
            this.txtMonth.Location = new System.Drawing.Point(206, 262);
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.Size = new System.Drawing.Size(27, 20);
            this.txtMonth.TabIndex = 23;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(252, 262);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(40, 20);
            this.txtYear.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(190, 265);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "/";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(236, 265);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(12, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "/";
            // 
            // txtWheel
            // 
            this.txtWheel.Location = new System.Drawing.Point(161, 294);
            this.txtWheel.Name = "txtWheel";
            this.txtWheel.Size = new System.Drawing.Size(121, 20);
            this.txtWheel.TabIndex = 27;
            // 
            // txtSpeeds
            // 
            this.txtSpeeds.Location = new System.Drawing.Point(161, 326);
            this.txtSpeeds.Name = "txtSpeeds";
            this.txtSpeeds.Size = new System.Drawing.Size(121, 20);
            this.txtSpeeds.TabIndex = 28;
            // 
            // txtSeatH
            // 
            this.txtSeatH.Location = new System.Drawing.Point(161, 358);
            this.txtSeatH.Name = "txtSeatH";
            this.txtSeatH.Size = new System.Drawing.Size(121, 20);
            this.txtSeatH.TabIndex = 29;
            // 
            // txtGroundH
            // 
            this.txtGroundH.Location = new System.Drawing.Point(161, 454);
            this.txtGroundH.Name = "txtGroundH";
            this.txtGroundH.Size = new System.Drawing.Size(121, 20);
            this.txtGroundH.TabIndex = 32;
            // 
            // cboSuspension
            // 
            this.cboSuspension.FormattingEnabled = true;
            this.cboSuspension.Location = new System.Drawing.Point(161, 422);
            this.cboSuspension.Name = "cboSuspension";
            this.cboSuspension.Size = new System.Drawing.Size(121, 21);
            this.cboSuspension.TabIndex = 33;
            // 
            // cboPedal
            // 
            this.cboPedal.FormattingEnabled = true;
            this.cboPedal.Location = new System.Drawing.Point(161, 390);
            this.cboPedal.Name = "cboPedal";
            this.cboPedal.Size = new System.Drawing.Size(121, 21);
            this.cboPedal.TabIndex = 34;
            // 
            // btnDisplayAll
            // 
            this.btnDisplayAll.Location = new System.Drawing.Point(474, 25);
            this.btnDisplayAll.Name = "btnDisplayAll";
            this.btnDisplayAll.Size = new System.Drawing.Size(127, 23);
            this.btnDisplayAll.TabIndex = 35;
            this.btnDisplayAll.Text = "Display all bikes";
            this.btnDisplayAll.UseVisualStyleBackColor = true;
            this.btnDisplayAll.Click += new System.EventHandler(this.btnDisplayAll_Click);
            // 
            // btnDisplayMountain
            // 
            this.btnDisplayMountain.Location = new System.Drawing.Point(334, 65);
            this.btnDisplayMountain.Name = "btnDisplayMountain";
            this.btnDisplayMountain.Size = new System.Drawing.Size(419, 23);
            this.btnDisplayMountain.TabIndex = 36;
            this.btnDisplayMountain.Text = "Diplay mountain bikes";
            this.btnDisplayMountain.UseVisualStyleBackColor = true;
            this.btnDisplayMountain.Click += new System.EventHandler(this.btnDisplayMountain_Click);
            // 
            // btnDisplayRoad
            // 
            this.btnDisplayRoad.Location = new System.Drawing.Point(334, 228);
            this.btnDisplayRoad.Name = "btnDisplayRoad";
            this.btnDisplayRoad.Size = new System.Drawing.Size(419, 23);
            this.btnDisplayRoad.TabIndex = 37;
            this.btnDisplayRoad.Text = "Diplay road bikes";
            this.btnDisplayRoad.UseVisualStyleBackColor = true;
            this.btnDisplayRoad.Click += new System.EventHandler(this.btnDisplayRoad_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(38, 136);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 38;
            this.label13.Text = "Type of Bike";
            // 
            // cboBikeType
            // 
            this.cboBikeType.FormattingEnabled = true;
            this.cboBikeType.Location = new System.Drawing.Point(161, 133);
            this.cboBikeType.Name = "cboBikeType";
            this.cboBikeType.Size = new System.Drawing.Size(121, 21);
            this.cboBikeType.TabIndex = 39;
            // 
            // lstViewRoad
            // 
            this.lstViewRoad.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderRSerial,
            this.columnHeaderRModel,
            this.columnHeaderRColor,
            this.columnHeaderRDay,
            this.columnHeaderRMoth,
            this.columnHeaderRYear,
            this.columnHeaderRtype,
            this.columnHeaderRWheel,
            this.columnHeaderRSpeeds,
            this.columnHeaderSeatH,
            this.columnHeaderPedal,
            this.columnHeaderRSize});
            this.lstViewRoad.Location = new System.Drawing.Point(334, 257);
            this.lstViewRoad.Name = "lstViewRoad";
            this.lstViewRoad.Size = new System.Drawing.Size(419, 97);
            this.lstViewRoad.TabIndex = 40;
            this.lstViewRoad.UseCompatibleStateImageBehavior = false;
            this.lstViewRoad.View = System.Windows.Forms.View.Details;
            this.lstViewRoad.SelectedIndexChanged += new System.EventHandler(this.lstViewRoad_SelectedIndexChanged);
            // 
            // columnHeaderRSerial
            // 
            this.columnHeaderRSerial.Text = "Serial";
            // 
            // columnHeaderRModel
            // 
            this.columnHeaderRModel.Text = "Model";
            // 
            // columnHeaderRColor
            // 
            this.columnHeaderRColor.Text = "Color";
            // 
            // columnHeaderRDay
            // 
            this.columnHeaderRDay.Text = "M-Day";
            // 
            // columnHeaderRMoth
            // 
            this.columnHeaderRMoth.Text = "M-Month";
            // 
            // columnHeaderRYear
            // 
            this.columnHeaderRYear.Text = "M-Year";
            // 
            // columnHeaderRtype
            // 
            this.columnHeaderRtype.DisplayIndex = 11;
            this.columnHeaderRtype.Text = "type";
            // 
            // columnHeaderRWheel
            // 
            this.columnHeaderRWheel.DisplayIndex = 6;
            this.columnHeaderRWheel.Text = "Wheel Size";
            // 
            // columnHeaderRSpeeds
            // 
            this.columnHeaderRSpeeds.DisplayIndex = 7;
            this.columnHeaderRSpeeds.Text = "Speeds";
            // 
            // columnHeaderSeatH
            // 
            this.columnHeaderSeatH.DisplayIndex = 8;
            this.columnHeaderSeatH.Text = "SeatHeigth";
            // 
            // columnHeaderPedal
            // 
            this.columnHeaderPedal.DisplayIndex = 9;
            this.columnHeaderPedal.Text = "Pedal";
            // 
            // columnHeaderRSize
            // 
            this.columnHeaderRSize.DisplayIndex = 10;
            this.columnHeaderRSize.Text = "Size";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 500);
            this.Controls.Add(this.lstViewRoad);
            this.Controls.Add(this.cboBikeType);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnDisplayRoad);
            this.Controls.Add(this.btnDisplayMountain);
            this.Controls.Add(this.btnDisplayAll);
            this.Controls.Add(this.cboPedal);
            this.Controls.Add(this.cboSuspension);
            this.Controls.Add(this.txtGroundH);
            this.Controls.Add(this.txtSeatH);
            this.Controls.Add(this.txtSpeeds);
            this.Controls.Add(this.txtWheel);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.txtMonth);
            this.Controls.Add(this.txtDay);
            this.Controls.Add(this.cboColor);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSerial);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstViewMountain);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnAdd);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ListView lstViewMountain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSerial;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboColor;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.TextBox txtMonth;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtWheel;
        private System.Windows.Forms.TextBox txtSpeeds;
        private System.Windows.Forms.TextBox txtSeatH;
        private System.Windows.Forms.TextBox txtGroundH;
        private System.Windows.Forms.ComboBox cboSuspension;
        private System.Windows.Forms.ComboBox cboPedal;
        private System.Windows.Forms.Button btnDisplayAll;
        private System.Windows.Forms.Button btnDisplayMountain;
        private System.Windows.Forms.Button btnDisplayRoad;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboBikeType;
        private System.Windows.Forms.ColumnHeader columnHeaderSerial;
        private System.Windows.Forms.ColumnHeader columnHeaderModel;
        private System.Windows.Forms.ColumnHeader columnHeaderColor;
        private System.Windows.Forms.ColumnHeader columnHeaderDay;
        private System.Windows.Forms.ColumnHeader columnHeaderMonth;
        private System.Windows.Forms.ColumnHeader columnHeaderYear;
        private System.Windows.Forms.ColumnHeader columnHeaderWheel;
        private System.Windows.Forms.ColumnHeader columnHeaderSpeeds;
        private System.Windows.Forms.ColumnHeader columnHeaderSuspension;
        private System.Windows.Forms.ColumnHeader columnHeaderGroundH;
        private System.Windows.Forms.ListView lstViewRoad;
        private System.Windows.Forms.ColumnHeader columnHeaderRSerial;
        private System.Windows.Forms.ColumnHeader columnHeaderRModel;
        private System.Windows.Forms.ColumnHeader columnHeaderRColor;
        private System.Windows.Forms.ColumnHeader columnHeaderRDay;
        private System.Windows.Forms.ColumnHeader columnHeaderRMoth;
        private System.Windows.Forms.ColumnHeader columnHeaderRYear;
        private System.Windows.Forms.ColumnHeader columnHeaderRWheel;
        private System.Windows.Forms.ColumnHeader columnHeaderRSpeeds;
        private System.Windows.Forms.ColumnHeader columnHeaderSeatH;
        private System.Windows.Forms.ColumnHeader columnHeaderPedal;
        private System.Windows.Forms.ColumnHeader columnHeaderSize;
        private System.Windows.Forms.ColumnHeader columnHeaderRSize;
        private System.Windows.Forms.ColumnHeader columnHeadertype;
        private System.Windows.Forms.ColumnHeader columnHeaderRtype;
    }
}

