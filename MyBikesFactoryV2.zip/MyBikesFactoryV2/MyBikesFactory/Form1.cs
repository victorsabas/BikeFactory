﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;


namespace MyBikesFactory
{
    public partial class Form1 : Form
    {
        // declair lists
        List<RoadBike> listRoad = new List<RoadBike>();
        List<MountainBike> listMountain = new List<MountainBike>();
        List<ISize> listBikes = new List<ISize>();


        static String myFile = @"../../data/Bikes.bin";
        int index = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // fill type of bike combo box 
            foreach (EnumBikes element in Enum.GetValues(typeof(EnumBikes)))
            {
                cboBikeType.Items.Add(element);
                cboBikeType.Text = Convert.ToString(cboBikeType.Items[0]);
            }

            //fill color combo box
            foreach (EnumColor element in Enum.GetValues(typeof(EnumColor)))
            {
                cboColor.Items.Add(element);
                cboColor.Text = Convert.ToString(cboColor.Items[0]);
            }

            // fill pedal type combo box
            foreach (EnumPedal element in Enum.GetValues(typeof(EnumPedal)))
            {
               cboPedal.Items.Add(element);
                cboPedal.Text = Convert.ToString(cboPedal.Items[0]);
            }

            // fill suspension combo box 
            foreach (EnumSuspension element in Enum.GetValues(typeof(EnumSuspension)))
            {
                cboSuspension.Items.Add(element);
                cboSuspension.Text = Convert.ToString(cboSuspension.Items[0]);
            }
        }
        //******************************* add button*******************************
        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.txtSerial.Focus();
            if (cboBikeType.SelectedIndex == 0)
            {
                RoadBike aRoad = new RoadBike();
                aRoad.SerialNumber = Convert.ToInt32(txtSerial.Text);
                aRoad.Model = txtModel.Text;
                aRoad.Color = (EnumColor)cboColor.SelectedIndex;
                aRoad.MadeDate = new Date(Convert.ToInt32(txtDay.Text), Convert.ToInt32(txtMonth.Text), 
                                            Convert.ToInt32(txtYear.Text));
                aRoad.TypeBike = (EnumBikes)cboBikeType.SelectedIndex;
                aRoad.WheelsSize = Convert.ToDouble(txtWheel.Text);
                aRoad.Speeds = Convert.ToInt32(txtSpeeds.Text);
                aRoad.SeatHeight = Convert.ToDouble(txtSeatH.Text);
                aRoad.PedalType = (EnumPedal)cboPedal.SelectedIndex;
                

                this.listBikes.Add(aRoad);
                

            }
            else if (cboBikeType.SelectedIndex == 1)
            {
                MountainBike aMountain = new MountainBike();
                aMountain.SerialNumber = Convert.ToInt32(txtSerial.Text);
                aMountain.Model = txtModel.Text;
                aMountain.Color = (EnumColor)cboColor.SelectedIndex;
                aMountain.MadeDate = new Date(Convert.ToInt32(txtDay.Text), Convert.ToInt32(txtMonth.Text),
                                            Convert.ToInt32(txtYear.Text));
                aMountain.TypeBike = (EnumBikes)cboBikeType.SelectedIndex;
                aMountain.WheelsSize = Convert.ToDouble(txtWheel.Text);
                aMountain.Speeds = Convert.ToInt32(txtSpeeds.Text);
                aMountain.SuspensionType = (EnumSuspension)cboSuspension.SelectedIndex;
                aMountain.GroundHeight = Convert.ToDouble(txtGroundH.Text);


                this.listBikes.Add(aMountain);


            }

            foreach (ISize element in listBikes)
            {
                if (element is RoadBike)
                {
                    listRoad.Add((RoadBike)element);


                }
                if (element is MountainBike)
                {
                    listMountain.Add((MountainBike)element);


                }
            }
            Reset();
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure that you want to update this record?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                if (cboBikeType.SelectedIndex == 0)
                {
                    this.listRoad[index].SerialNumber = Convert.ToInt32(txtSerial.Text);
                    this.listRoad[index].Model = txtModel.Text;
                    this.listRoad[index].Color = (EnumColor)cboColor.SelectedIndex;
                    this.listRoad[index].MadeDate.Day = Convert.ToInt32(txtDay.Text);
                    this.listRoad[index].MadeDate.Month = Convert.ToInt32(txtMonth.Text);
                    this.listRoad[index].MadeDate.Year = Convert.ToInt32(txtYear.Text);
                    this.listRoad[index].TypeBike = (EnumBikes)cboBikeType.SelectedIndex;
                    this.listRoad[index].WheelsSize = Convert.ToDouble(txtWheel.Text);
                    this.listRoad[index].Speeds = Convert.ToInt32(txtSpeeds.Text);
                    this.listRoad[index].SeatHeight = Convert.ToDouble(txtSeatH);
                    this.listRoad[index].PedalType = (EnumPedal)cboPedal.SelectedIndex;
                                  


                    
                }
                else if (cboBikeType.SelectedIndex == 1)
                {
                    this.listMountain[index].SerialNumber = Convert.ToInt32(txtSerial.Text);
                    this.listMountain[index].Model = txtModel.Text;
                    this.listMountain[index].Color = (EnumColor)cboColor.SelectedIndex;
                    this.listMountain[index].MadeDate.Day = Convert.ToInt32(txtDay.Text);
                    this.listMountain[index].MadeDate.Month = Convert.ToInt32(txtMonth.Text);
                    this.listMountain[index].MadeDate.Year = Convert.ToInt32(txtYear.Text);
                    this.listMountain[index].TypeBike = (EnumBikes)cboBikeType.SelectedIndex;
                    this.listMountain[index].WheelsSize = Convert.ToDouble(txtWheel.Text);
                    this.listMountain[index].Speeds = Convert.ToInt32(txtSpeeds.Text);
                    this.listMountain[index].SuspensionType = (EnumSuspension)cboSuspension.SelectedIndex;
                    this.listMountain[index].GroundHeight = Convert.ToDouble(txtGroundH.Text);
                }
                else
                { MessageBox.Show("Please select either Road bike or Mountain bike to Delete"); }

                MessageBox.Show("Record index: " + index + " updated");

               this.lstViewMountain.Items.Clear(); this.lstViewRoad.Items.Clear();




            }
            else { MessageBox.Show("Data not found"); }
            Reset();
        }

        private void btnDisplayAll_Click(object sender, EventArgs e)
        {
            if (this.listBikes.Capacity != 0)
            {
                foreach (RoadBike element in this.listRoad)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.SerialNumber));

                    item.SubItems.Add(Convert.ToString(element.Model));
                    item.SubItems.Add(Convert.ToString(element.Color));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Day));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Month));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Year));
                    item.SubItems.Add(Convert.ToString(element.TypeBike));
                    item.SubItems.Add(Convert.ToString(element.WheelsSize));
                    item.SubItems.Add(Convert.ToString(element.Speeds));
                    item.SubItems.Add(Convert.ToString(element.SeatHeight));
                    item.SubItems.Add(Convert.ToString(element.PedalType));
                    item.SubItems.Add(Convert.ToString(element.CalculBikeSize()));


                    //this.listViewMemberInfos.Items.Add(item);
                    this.lstViewRoad.Items.Add(item);

                }
                foreach (MountainBike element in this.listMountain)
                {
                    ListViewItem record = new ListViewItem(Convert.ToString(element.SerialNumber));
                    record.SubItems.Add(Convert.ToString(element.Model));
                    record.SubItems.Add(Convert.ToString(element.Color));
                    record.SubItems.Add(Convert.ToString(element.MadeDate.Day));
                    record.SubItems.Add(Convert.ToString(element.MadeDate.Month));
                    record.SubItems.Add(Convert.ToString(element.MadeDate.Year));
                    record.SubItems.Add(Convert.ToString(element.TypeBike));
                    record.SubItems.Add(Convert.ToString(element.WheelsSize));
                    record.SubItems.Add(Convert.ToString(element.Speeds));
                    record.SubItems.Add(Convert.ToString(element.SuspensionType));
                    record.SubItems.Add(Convert.ToString(element.GroundHeight));
                    record.SubItems.Add(Convert.ToString(element.CalculBikeSize()));

                    //this.listViewMemberInfos.Items.Add(item);
                    this.lstViewMountain.Items.Add(record);

                }
            }
            else
            {
                MessageBox.Show("...NO DATA.....");
            }
        }

        private void btnDisplayMountain_Click(object sender, EventArgs e)
        {
            if (this.listMountain.Capacity != 0)
            {
                foreach (MountainBike element in this.listMountain)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.SerialNumber));

                    item.SubItems.Add(Convert.ToString(element.Model));
                    item.SubItems.Add(Convert.ToString(element.Color));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Day));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Month));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Year));
                    item.SubItems.Add(Convert.ToString(element.TypeBike));
                    item.SubItems.Add(Convert.ToString(element.WheelsSize));
                    item.SubItems.Add(Convert.ToString(element.Speeds));
                    item.SubItems.Add(Convert.ToString(element.SuspensionType));
                    item.SubItems.Add(Convert.ToString(element.GroundHeight));
                    item.SubItems.Add(Convert.ToString(element.CalculBikeSize()));



                    this.lstViewMountain.Items.Add(item);

                }

            }
            else
            {
                MessageBox.Show("...NO DATA.....");
            }
        }

        private void btnDisplayRoad_Click(object sender, EventArgs e)
        {
            if (this.listRoad.Capacity != 0)
            {
                foreach (RoadBike element in this.listRoad)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.SerialNumber));

                    item.SubItems.Add(Convert.ToString(element.Model));
                    item.SubItems.Add(Convert.ToString(element.Color));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Day));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Month));
                    item.SubItems.Add(Convert.ToString(element.MadeDate.Year));
                    item.SubItems.Add(Convert.ToString(element.TypeBike));
                    item.SubItems.Add(Convert.ToString(element.WheelsSize));
                    item.SubItems.Add(Convert.ToString(element.Speeds));
                    item.SubItems.Add(Convert.ToString(element.SeatHeight));
                    item.SubItems.Add(Convert.ToString(element.PedalType));
                    item.SubItems.Add(Convert.ToString(element.CalculBikeSize()));



                    this.lstViewRoad.Items.Add(item);

                }

            }
            else
            {
                MessageBox.Show("...NO DATA.....");
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (File.Exists(myFile))
            {
                FileStream fs = new FileStream(myFile, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                listBikes = (List<ISize>)bin.Deserialize(fs);

                fs.Close();

               
            }



            foreach (Bike record in listBikes)
            {
                if (record is RoadBike)
                {
                    RoadBike aRoad = new RoadBike();
                    aRoad = (RoadBike)record;
                    ListViewItem element = new ListViewItem(Convert.ToString(record.SerialNumber));

                    element.SubItems.Add(Convert.ToString(record.Model));
                    element.SubItems.Add(Convert.ToString(record.Color));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Day));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Month));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Year));
                    element.SubItems.Add(Convert.ToString(record.TypeBike));
                    element.SubItems.Add(Convert.ToString(record.WheelsSize));
                    element.SubItems.Add(Convert.ToString(record.Speeds));
                    element.SubItems.Add(Convert.ToString(aRoad.SeatHeight));
                    element.SubItems.Add(Convert.ToString(aRoad.PedalType));
                    element.SubItems.Add(Convert.ToString(record.CalculBikeSize()));

                   
                    this.lstViewRoad.Items.Add(element);
                }
                else if (record is MountainBike)
                {
                    MountainBike aMountain = new MountainBike();
                    aMountain = (MountainBike)record;
                    ListViewItem element = new ListViewItem(Convert.ToString(record.SerialNumber));

                    element.SubItems.Add(Convert.ToString(record.Model));
                    element.SubItems.Add(Convert.ToString(record.Color));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Day));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Month));
                    element.SubItems.Add(Convert.ToString(record.MadeDate.Year));
                    element.SubItems.Add(Convert.ToString(record.TypeBike));
                    element.SubItems.Add(Convert.ToString(record.WheelsSize));
                    element.SubItems.Add(Convert.ToString(record.Speeds));
                    element.SubItems.Add(Convert.ToString(aMountain.SuspensionType));
                    element.SubItems.Add(Convert.ToString(aMountain.GroundHeight));
                    element.SubItems.Add(Convert.ToString(record.CalculBikeSize()));

                    this.lstViewMountain.Items.Add(element);
                }
            }

     
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(myFile, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, listBikes);
            fs.Close();
        }

        private void lstViewMountain_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = lstViewMountain.FocusedItem.Index;
            foreach (MountainBike record in listMountain) 
            {
                txtSerial.Text = Convert.ToString(listMountain[index].SerialNumber);
                txtModel.Text = Convert.ToString(listMountain[index].Model);
                cboColor.Text = Convert.ToString(listMountain[index].Color);
                txtDay.Text = Convert.ToString(listMountain[index].MadeDate.Day);
                txtMonth.Text = Convert.ToString(listMountain[index].MadeDate.Month);
                txtYear.Text = Convert.ToString(listMountain[index].MadeDate.Year);
                cboBikeType.Text = Convert.ToString(listMountain[index].TypeBike);
                txtWheel.Text = Convert.ToString(listMountain[index].WheelsSize);
                txtSpeeds.Text = Convert.ToString(listMountain[index].Speeds);
                cboSuspension.Text = Convert.ToString(listMountain[index].SuspensionType);
                txtGroundH.Text = Convert.ToString(listMountain[index].GroundHeight);
            }
            txtSerial.Enabled = false;
        }


        private void lstViewRoad_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = lstViewRoad.FocusedItem.Index;
            foreach (RoadBike record in listRoad)
            {
                txtSerial.Text = Convert.ToString(listRoad[index].SerialNumber);
                txtModel.Text = Convert.ToString(listRoad[index].Model);
                cboColor.Text = Convert.ToString(listRoad[index].Color);
                txtDay.Text = Convert.ToString(listRoad[index].MadeDate.Day);
                txtMonth.Text = Convert.ToString(listRoad[index].MadeDate.Month);
                txtYear.Text = Convert.ToString(listRoad[index].MadeDate.Year);
                cboBikeType.Text = Convert.ToString(listRoad[index].TypeBike);
                txtWheel.Text = Convert.ToString(listRoad[index].WheelsSize);
                txtSpeeds.Text = Convert.ToString(listRoad[index].Speeds);
                txtSeatH.Text= Convert.ToString(listRoad[index].SeatHeight);
                cboPedal.Text = Convert.ToString(listRoad[index].PedalType);
            }
            txtSerial.Enabled = false;

        }
        // function Reset
        void Reset ()
        {
            txtSerial.Text = "";
            txtModel.Text = "";
            txtDay.Text = "";
            txtMonth.Text = "";
            txtYear.Text = "";
            txtWheel.Text = "";
            txtSpeeds.Text = "";
            txtSeatH.Text = "";
            txtGroundH.Text = "";
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

            if (lstViewRoad.FocusedItem.Index >= 0)
            {
                listRoad.RemoveAt(lstViewRoad.FocusedItem.Index);
                listBikes.RemoveAt(lstViewRoad.FocusedItem.Index);
            }
            if (lstViewMountain.FocusedItem.Index >= 0)
            {
                listMountain.RemoveAt(lstViewMountain.FocusedItem.Index);
                listBikes.RemoveAt(lstViewMountain.FocusedItem.Index);
            }
            this.lstViewMountain.Items.Clear(); this.lstViewRoad.Items.Clear();

            if (cboBikeType.SelectedIndex == 0)
            {
                foreach (RoadBike item in this.listRoad)
                {
                    ListViewItem element = new ListViewItem(Convert.ToString(item.SerialNumber));

                    element.SubItems.Add(Convert.ToString(item.Model));
                    element.SubItems.Add(Convert.ToString(item.Color));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Day));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Month));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Year));
                    element.SubItems.Add(Convert.ToString(item.TypeBike));
                    element.SubItems.Add(Convert.ToString(item.WheelsSize));
                    element.SubItems.Add(Convert.ToString(item.Speeds));
                    element.SubItems.Add(Convert.ToString(item.SeatHeight));
                    element.SubItems.Add(Convert.ToString(item.PedalType));
                    element.SubItems.Add(Convert.ToString(item.CalculBikeSize()));

                    
                    this.lstViewRoad.Items.Add(element);

                }
            }
            else if (cboBikeType.SelectedIndex == 1)
            {
                foreach (MountainBike item in this.listMountain)
                {
                    ListViewItem element = new ListViewItem(Convert.ToString(item.SerialNumber));

                    element.SubItems.Add(Convert.ToString(item.Model));
                    element.SubItems.Add(Convert.ToString(item.Color));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Day));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Month));
                    element.SubItems.Add(Convert.ToString(item.MadeDate.Year));
                    element.SubItems.Add(Convert.ToString(item.TypeBike));
                    element.SubItems.Add(Convert.ToString(item.WheelsSize));
                    element.SubItems.Add(Convert.ToString(item.Speeds));
                    element.SubItems.Add(Convert.ToString(item.SuspensionType));
                    element.SubItems.Add(Convert.ToString(item.GroundHeight));
                    element.SubItems.Add(Convert.ToString(item.CalculBikeSize()));

                    
                    this.lstViewMountain.Items.Add(element);

                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (cboBikeType.SelectedIndex == 0)
            {
                bool found = false;
                RoadBike someRoadBike = new RoadBike();
                foreach (RoadBike item in this.listRoad)
                {
                    if (item.SerialNumber == Convert.ToInt32(txtSearch.Text))
                    {
                        found = true;
                        someRoadBike = item;
                    }
                }
                if (found == true)
                {
                    MessageBox.Show("Road Bike: " + someRoadBike + " found!!");
                }
                else { MessageBox.Show("Bike NOT found "); }
            }
            else if (cboBikeType.SelectedIndex == 1)
            {
                bool found = false;
                MountainBike someMountainBike = new MountainBike();
                foreach (MountainBike item in this.listMountain)
                {
                    if (item.SerialNumber == Convert.ToInt32(txtSearch.Text))
                    {
                        found = true;
                        someMountainBike = item;
                    }
                }
                if (found == true)
                {
                    MessageBox.Show("Teacher: " + someMountainBike + " found!!");
                }
                else { MessageBox.Show("Teacher NOT found "); }
            }
            else if (cboBikeType.SelectedIndex == 2)
            {
                MessageBox.Show("Please type a serial number in the search box");
            }
        }
    }
}
