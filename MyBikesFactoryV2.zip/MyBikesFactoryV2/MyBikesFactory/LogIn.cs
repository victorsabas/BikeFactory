﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyBikesFactory
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void ValidateAlpha(KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar))
            {

                MessageBox.Show("Must be a digit only");
                e.Handled = true;

            }
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click_1(object sender, EventArgs e)
        {
            this.textBoxLoginId.Focus();
            if (this.textBoxLoginId.Text == "user" && this.textBoxPassword.Text == "555")
            {
                Form1 myMainForm = new Form1();
                myMainForm.ShowDialog();
            }
            else { MessageBox.Show("Wrong Student ID or PASSWORD"); }
        }

        private void buttonLogout_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("End of the Application, Thank You!!");
            this.Close();
        }

        private void buttonResetLogin_Click_1(object sender, EventArgs e)
        {
            this.textBoxLoginId.Text = "";
            this.textBoxPassword.Text = "";
            this.textBoxLoginId.Focus();
        }
    }
}
