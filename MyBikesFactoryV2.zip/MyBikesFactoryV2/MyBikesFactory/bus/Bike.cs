﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikesFactory
{
    [Serializable]
    public abstract class Bike : ISize
    {
        //fields
        private int serialNumber;
        private String model;
        private EnumColor color;
        private Date madeDate;
        private double wheelsSize;
        private int speeds;
        private EnumBikes typeBike;

        //getters and setters
        public int SerialNumber { get => serialNumber; set => serialNumber = value; }
        public string Model { get => model; set => model = value; }
        public EnumColor Color { get => color; set => color = value; }
        public Date MadeDate { get => madeDate; set => madeDate = value; }
        public double WheelsSize { get => wheelsSize; set => wheelsSize = value; }
        public int Speeds { get => speeds; set => speeds = value; }
        public EnumBikes TypeBike { get => typeBike; set => typeBike = value; }



        // contructors
        public Bike()
        {
            this.SerialNumber = 0000;
            this.Model = "unkown";
            this.Color = EnumColor.unkown;
            this.MadeDate = madeDate;
            this.WheelsSize = 00;
            this.Speeds = 00;
            this.TypeBike = EnumBikes.unkonw;
           
        }
        public Bike(int serialNumber, string model, EnumColor color, Date madeDate, double wheelsSize, int speeds)
        {
            this.SerialNumber = serialNumber;
            this.Model = model;
            this.Color = color;
            this.MadeDate = madeDate;
            this.WheelsSize = wheelsSize;
            this.Speeds = speeds;
            this.TypeBike = typeBike;
            
        }

        public override String ToString()
        {
            return this.SerialNumber + " - " +
                    this.Model + " - " +
                    this.Color + " - " +
                    this.MadeDate + " - " +
                    this.WheelsSize + " - " +
                    this.Speeds + " - " + this.TypeBike;
        }

        public abstract double CalculBikeSize();

    }
}