﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikesFactory
{
    [Serializable]
    public class MountainBike : Bike
    {
        private EnumSuspension suspensionType;
        private Double groundHeight;

        public EnumSuspension SuspensionType { get => suspensionType; set => suspensionType = value; }
        public double GroundHeight { get => groundHeight; set => groundHeight = value; }


        public MountainBike()
        {
            SuspensionType = EnumSuspension.unkown;
            GroundHeight = 00;
        }


        public MountainBike(EnumSuspension suspensionType, double groundHeight)
        {
            this.SuspensionType = suspensionType;
            this.GroundHeight = groundHeight;
        }

        public override string ToString()
        {
            return base.ToString() + " - " + this.SuspensionType + " - " + this.GroundHeight + this.CalculBikeSize();
        }

        public override double CalculBikeSize()
        {
            return this.GroundHeight * 2.5;
        }
    }
}