﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikesFactory
{
    [Serializable]
    public class RoadBike : Bike
    {
        private double seatHeight;
        private EnumPedal pedalType;

        public double SeatHeight { get => seatHeight; set => seatHeight = value; }
        public EnumPedal PedalType { get => pedalType; set => pedalType = value; }

        public RoadBike()
        {
            SeatHeight = 00;
            PedalType = EnumPedal.unkown;
        }

        public RoadBike(double seatHeight, EnumPedal pedalType1)
        {
            SeatHeight = seatHeight;
            PedalType = pedalType;
        }

        public override string ToString()
        {
            return base.ToString() + " - " +  this.SeatHeight + " - " + this.PedalType + " - " + this.CalculBikeSize(); 
        }

        public override double CalculBikeSize()
        {
            return this.SeatHeight * 1.79;
        }
    }
}